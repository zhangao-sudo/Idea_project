package com.leyou.mapper;

import com.item.leyou.pojo.Stock;
import tk.mybatis.mapper.common.Mapper;

/**
 * Created by Zhang Ao on 2020/1/22 14:21
 * Email:17863572518@163.com
 */
public interface  StockMapper extends Mapper<Stock> {
}
