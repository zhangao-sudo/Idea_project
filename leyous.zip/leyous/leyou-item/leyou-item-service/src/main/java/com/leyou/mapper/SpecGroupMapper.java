package com.leyou.mapper;

import com.item.leyou.pojo.SpecGroup;
import tk.mybatis.mapper.common.Mapper;

/**
 * Created by Zhang Ao on 2020/1/21 19:12
 * Email:17863572518@163.com
 */
public interface SpecGroupMapper extends Mapper<SpecGroup> {
}
