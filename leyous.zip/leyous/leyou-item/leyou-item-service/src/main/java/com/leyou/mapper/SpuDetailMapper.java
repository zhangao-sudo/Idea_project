package com.leyou.mapper;

import com.item.leyou.pojo.SpuDtail;
import tk.mybatis.mapper.common.Mapper;

/**
 * Created by Zhang Ao on 2020/1/22 14:20
 * Email:17863572518@163.com
 */
public interface SpuDetailMapper extends Mapper<SpuDtail> {
}
