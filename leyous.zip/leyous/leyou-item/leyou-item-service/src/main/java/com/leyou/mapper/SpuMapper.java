package com.leyou.mapper;

import com.item.leyou.bo.SpuBo;
import com.item.leyou.pojo.Spu;
import tk.mybatis.mapper.common.Mapper;

/**
 * Created by Zhang Ao on 2020/1/21 20:46
 * Email:17863572518@163.com
 */
public interface SpuMapper extends Mapper<Spu> {
}
