package com.leyou.mapper;

import com.item.leyou.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;


/**
 * Created by Zhang Ao on 2020/1/22 14:23
 * Email:17863572518@163.com
 */
public interface SkuMapper extends Mapper<Sku> {
}
