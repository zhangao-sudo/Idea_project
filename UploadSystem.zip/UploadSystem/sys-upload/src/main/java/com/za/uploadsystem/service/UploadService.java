package com.za.uploadsystem.service;

import com.za.uploadsystem.controller.UploadController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Zhang Ao on 2020/5/14 22:07
 * Email:17863572518@163.com
 */
@Service
public class UploadService {
    public ResponseEntity<?> upload(MultipartFile multipartFile){
        //获取本项目路径
        String path = UploadService.class.getResource("/").getPath();
        System.out.println(path);
        // String path="E:\\Download\\homework\\";
        //分级目录
        String dir="file/";
        //文件名称
        String originalFilename = multipartFile.getOriginalFilename();
        //得到文件路径
        String allpath=path+dir+originalFilename;
        String targetpath=path+dir;
        //判断文件是否存在
        File exfile = new File(allpath);
        File targetfile =new File(targetpath);
        if(exfile.exists())
        {   //文件名重复
            return  new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
        }else {

            try {

                targetfile.mkdirs();
                boolean newFile = exfile.createNewFile();
                if(!newFile){
                    return  new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //写入服务器
        byte[] b = new byte[1024];

        try {
            InputStream inputStream = multipartFile.getInputStream();

            FileOutputStream fileOutputStream = new FileOutputStream(exfile);
            while (true) {// 循环读取数据

                // 一次读取1024个字节
                int length = inputStream.read(b, 0, b.length);
                // 如果返回的字节为-1，代表已经没有数据
                // break，跳出循环
                if (length == -1) {
                    break;
                }
                fileOutputStream.write(b, 0, length);// 一次写入1024个字节
            }
            fileOutputStream.flush();
            inputStream.close();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            return  new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<Object>(HttpStatus.ACCEPTED);
    }

    public ResponseEntity<List<String>> queryallfile() {
        ArrayList<String> strings = new ArrayList<>();
        String path = UploadService.class.getResource("/").getPath();

        String dir = "file";
        File file = new File(path + dir);

        String[] list = file.list();
        if(list==null){
            return new ResponseEntity<>(null, HttpStatus.ACCEPTED);
        }
        for (String filename : list) {
            strings.add(filename);
        }
        return new ResponseEntity<>(strings, HttpStatus.ACCEPTED);
    }

}
