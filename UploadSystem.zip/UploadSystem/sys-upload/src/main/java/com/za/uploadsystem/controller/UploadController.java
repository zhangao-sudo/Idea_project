package com.za.uploadsystem.controller;

import com.za.uploadsystem.service.UploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.List;

/**
 * Created by Zhang Ao on 2020/4/24 22:19
 * Email:17863572518@163.com
 */
@RestController
public class UploadController {
    @Autowired
    UploadService uploadService;

    @RequestMapping("/startup")
    public ResponseEntity<?> upload(@RequestPart("file") MultipartFile multipartFile){
       return this.uploadService.upload(multipartFile);
    }
    @RequestMapping("/queryall")
    public  ResponseEntity<List<String>> queryallfile(){
       return uploadService.queryallfile();
    }

}
