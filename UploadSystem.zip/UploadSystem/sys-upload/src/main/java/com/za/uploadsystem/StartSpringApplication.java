package com.za.uploadsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by Zhang Ao on 2020/4/24 22:11
 * Email:17863572518@163.com
 */
@SpringBootApplication
public class StartSpringApplication {
    public static void main(String[] args) {
        SpringApplication.run(StartSpringApplication.class);
    }
}
