#ifndef _A_H_
#define _A_H_


int start();
#endif
