/*取得init 进程（pid＝1）的组识别码*/
#include<stdio.h>
int main()
{
	printf("hello");	
	return 0;

}
		
